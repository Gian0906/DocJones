import { Component } from '@angular/core';
import { NavController,AlertController } from 'ionic-angular';
import {CartService} from '../../app/service/cartService';
import {RedditService} from '../../app/service/redditService';
import {CheckoutPage} from '../checkout/checkout';
import {SessionService} from '../../app/service/sessionService';
import {LoginPage} from '../login/login';
@Component({
  selector: 'page-contact',
  templateUrl: 'cart.html'
})
export class CartPage {
  cart:any;
  totalPrice:any=0;
  payment:any;
  url:any;
  logState:any=false;
  productPrice:any;
  totalQuery:any=0;
  constructor(public navCtrl: NavController,
              public redditService:RedditService,
              private sessionService:SessionService,
              public alertCtrl:AlertController,
              public cartService:CartService) {

    this.url = this.redditService.getUrl();
    console.log(this.url);

    this.logState = this.sessionService.getLogState();
}

ionViewDidLoad() {
this.cart = this.cartService.getCart();
console.log(this.cart);

this.totalQuery=this.cart.length;
for (var i = 0; i < this.cart.length; i++){
this.productPrice=this.cart[i].price * this.cart[i].quantity;

this.totalPrice = this.totalPrice + this.productPrice ;
console.log(this.totalPrice)
this.logState = this.sessionService.getLogState();

}

}

getValue(){
console.log(this.payment);
}


// submit(){
// console.log(this.payment)
// if(this.payment == "Pickup"){
// this.cartPanel = false;
// this.navCtrl.push(PickupPage,{
// payment:this.payment
// })
// }
// else if (this.payment == "Delivery"){
// this.cartPanel = false;
// this.navCtrl.push(CheckoutPage,{
// payment:this.payment
// });
// }
// }


closePanel(){
this.cartPanel = false;
}


cartPanel:any=false;
continue(){
  this.logState = this.sessionService.getLogState();

  if(this.logState != true){
    let alert = this.alertCtrl.create({
      title:'Notification Message',
      message:'Please login to your Account to proceed on your checkout',
      buttons:[{
        text:'Cancel',
      },{
        text:'Login',
        handler:()=>{
          this.navCtrl.push(LoginPage)
        }
      }]
    })
    alert.present();
  }
  else{
 this.navCtrl.push(CheckoutPage)
}
}

add(item,quantity){

this.cartService.updateItem(item.id,quantity+1);
this.cart=this.cartService.getCart();
this.totalPrice =0;
for(var i=0; i<this.cart.length; i++){
this.productPrice=this.cart[i].price * this.cart[i].quantity;

this.totalPrice +=this.productPrice;


}    
console.log(this.totalPrice)
}

minus(item,quantity){
this.cartService.updateItem(item.id,quantity-1)
this.cart=this.cartService.getCart();

this.totalPrice =0;
for(var i=0; i<this.cart.length; i++){
this.productPrice=this.cart[i].price * this.cart[i].quantity;

this.totalPrice += this.productPrice;
console.log(this.totalPrice)

}
}

removeItem(z){
this.cartService.removeItem(z);
this.cart=this.cartService.getCart();
this.totalQuery=this.cart.length;
this.totalPrice=0;
for (var i=0; i<this.cart.length; i++){
this.productPrice = this.cart[i].price * this.cart[i].quantity;
this.totalPrice = this.totalPrice + this.productPrice;


}
}


showRemove(order){
let alert = this.alertCtrl.create({
title:'Notication Message',
message:'Are you sure to remove ' + order.name +' from the list?',
buttons:[{
text:'Cancel',
},{
text:'Remove',
handler:(data=>{
this.removeItem(order.id);
})
}]
})
alert.present();
}
}

import{ Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'; 
import { HttpClientModule } from '@angular/common/http'; 

import { HTTP } from '@ionic-native/http';
import { AlertController} from 'ionic-angular'; 
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/toPromise';
import { CodegenComponentFactoryResolver } from '@angular/core/src/linker/component_factory_resolver';
import { BrowserGetTestability } from '@angular/platform-browser/src/browser/testability';
import { Observable } from 'rxjs/Observable';

// var url;

// var img_path = 'http://localhost/Jones'
// var email_path = 'http://rosalies.tech/Rosalies'

var url='http://localhost/Jones/api.php/'
// var url='http://u318491949.hostingerapp.com/Authentic/api.php/'
// var img_path = 'http://localhost/Authentic'

// var img_path = 'http://u318491949.hostingerapp.com/Authentic'
@Injectable()
export class RedditService{
baseUrl:string;

constructor(public http:HttpClient,
            public alertCtrl:AlertController){
    this.http=http;
}





getUrl(){
    // return img_path;
}


getTown(){
    var town;
    if(town){
        return Promise.resolve(town);
    }
    return new Promise(resolve=>{
        this.http.get(url+'category?include=menu&transform=1')
        .map(res=>res)
        .subscribe(data=>{
            town = data;
            resolve(town)
       
        });
      
    }) 
}


getProductbyCategory(code){
    var category;
    if(category){
        return Promise.resolve(category);
    }
    return new Promise(resolve=> {
       this.http.get(url+'menu?include=category&filter[]=cat_id,eq,'+code+'&filter[]=menu_status,eq,'+'Active'+'&transform=1')
       .map(res=> res)
       .subscribe(data=>{
           category=data;
           resolve(category);
       });
    });
   }

   getUseradd(id){
    var town;
    if(town){
        return Promise.resolve(town);
    }
    return new Promise(resolve=>{
        this.http.get(url+'customer_address?filter[]=cust_id,eq,'+id+'&transform=1')
        .map(res=>res)
        .subscribe(data=>{
            town = data;
            resolve(town)
       
        });
      
    }) 
   }


   getUserOrder(id){
    var town;
    if(town){
        return Promise.resolve(town);
    }
    return new Promise(resolve=>{
        this.http.get(url+'orders?filter[]=cust_id,eq,'+id+'&transform=1')
        .map(res=>res)
        .subscribe(data=>{
            town = data;
            resolve(town)
       
        });
      
    }) 
   }


   getOrderList(id){
    var town;
    if(town){
        return Promise.resolve(town);
    }
    return new Promise(resolve=>{
        this.http.get(url+'order_details?filter[]=ord_id,eq,'+id+'&transform=1')
        .map(res=>res)
        .subscribe(data=>{
            town = data;
            resolve(town)
       
        });
      
    }) 
   }


   checklogin(user,pass){
    var check;
    if(check){
        return Promise.resolve(check);
    }
        return new Promise (resolve=>{
            this.http.get(url+'customer_account?filter[]=cust_username,eq,'+ user +'&filter[]=cust_password,eq,'+pass+'&transform=1')
            .map(res => res)
            .subscribe(data=>{
            check=data;
            resolve(check);
            });
        });
    }


    postOrder(info){
        this.http.post(url+'orders?transform=1',info)
        .map(res=> res)
        .subscribe(data=>{
            console.log(data);
        },(err)=>{
            console.log("error");
        });
    }

        postOrderDetails(info){
            this.http.post(url+'order_details?transform=1',info)
            .map(res=> res)
            .subscribe(data=>{
                console.log(data);
            },(err)=>{
                console.log("error");
            });
}



checkConnection(ip){
    var allproduct;
    if(allproduct){
        return Promise.resolve(allproduct);
    }
    return new Promise(resolve=>{
        this.http.get('http://192.168.43.172/Jones/api.php/customer_account?&transform=1')
        .map(res=> res)
        .subscribe(data=>{
        allproduct=data;
        if(allproduct!=undefined){
            url='http://192.168.43.172/Jones/api.php/'
        //    img_path = 'http://'+ ip +'/Authentic'
           
        }
         resolve(allproduct);
        },(err)=>{
            console.log("error");
            let alert=this.alertCtrl.create({
                enableBackdropDismiss:false,
                title:'Connection Problem',
                message:'Please check the server ip address.',
                buttons: [
                  {
                    text: 'OK',
                    handler: ()=> {
                    console.log('error')
                    }
                  }
                ],
                });
                alert.present();
        });
    });
}




  

   


  




    
    
    
    


 }






import { Component } from '@angular/core';
import {  NavController, NavParams,AlertController,LoadingController,Nav } from 'ionic-angular';
import {CartService} from '../../app/service/cartService';
import {RedditService} from '../../app/service/redditService';
import {SessionService} from '../../app/service/sessionService';
import { DatePipe}from '@angular/common';
import { SuccessPage } from '../success/success';

@Component({
  selector: 'page-checkout',
  templateUrl: 'checkout.html',
})
export class CheckoutPage {
  cart:any;
  url:any;
  user:any;
  productPrice:any;
  totalPrice:any=0;
  time:any;
  date:any;
  year:any;
  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              public alertCtrl:AlertController,
              public loadingCtrl:LoadingController,
              public datepipe:DatePipe,
              public nav:Nav,
              private cartService:CartService,
              private sessionService:SessionService,
              private redditService:RedditService) {

                this.url = this.redditService.getUrl();
                this.user = this.sessionService.getUser();


                
    this.time = new Date();
    this.time = this.datepipe.transform(this.time, 'hh:mm:ss');





    this.date = new Date();
    this.date = this.datepipe.transform(this.date, 'yyyy-MM-dd');

    this.year = new Date();
    this.year = this.datepipe.transform(this.year, 'yyyy');
  }

  ionViewDidLoad() {
    this.cart = this.cartService.getCart();
    console.log(this.cart)
    this.getUserAddress();
    
console.log(this.cart);

for (var i = 0; i < this.cart.length; i++){
 this.productPrice=this.cart[i].price * this.cart[i].quantity;

 this.totalPrice = this.totalPrice + this.productPrice ;
 console.log(this.totalPrice)
  }
}

  user_data:any;
  user_list:any;
  getUserAddress(){
    this.redditService.getUseradd(this.user[0].cust_id)
    .then(data=>{
      this.user_data =data;
      this.user_list = this.user_data.customer_address;
      console.log(this.user_list);
    })
  }


submit(){
  let alert =this.alertCtrl.create({
    title:'Confirmation Message',
    message:'Are you sure to submit your order?',
    buttons:[{
      text:'Cancel'
    },{
      text:'Submit',
      handler:()=>{
        this.sendOrder();
      }
    }]
  })
  alert.present();
}

sendOrder(){
  var user = this.sessionService.getUser();
  var order_id = Math.floor(Math.random()* 3000000)
  let loader = this.loadingCtrl.create({
    spinner:'dots'
  });
  loader.present().then(() => {
    for (var i = 0; i < this.cart.length; i++) {
      let data = JSON.stringify({
      ord_id:'DOC'+'-'+this.year +'-'+order_id,
      menu_name: this.cart[i].name,
      
      // order_image: this.cart[i].product_image,
      // order_desc: this.cart[i].desc,
      // order_special: this.cart[i].special,
      menu_price: this.cart[i].price,
      od_qty: this.cart[i].quantity,
      od_status:'Pending',
      menu_id:this.cart[i].product_id,
      ord_subtotal: this.cart[i].price * this.cart[i].quantity,
      ord_img:this.cart[i].product_image
    
    });
    this.redditService.postOrderDetails(data)
  }




    let datas = JSON.stringify({
      ord_id:'DOC'+'-'+this.year +'-'+order_id,
      ord_date:this.date,
      ord_time:this.time,
      ord_totalamt:this.totalPrice,
      ord_status:'Pending',
      cust_id:user[0].cust_id
    })
    this.redditService.postOrder(datas);






  
    loader.dismiss();
  });
  this.nav.setRoot(SuccessPage)
  this.cartService.clearCart()
}

}

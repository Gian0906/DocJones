import { Component, ViewChild} from '@angular/core';
import { NavController, NavParams,AlertController,LoadingController,App,Nav,ToastController } from 'ionic-angular';
import { RedditService } from '../../app/service/redditService';
import { SessionService } from '../../app/service/sessionService';
import { CartService } from '../../app/service/cartService';
import {HomePage} from '../home/home';
import {AboutPage} from '../about/about';
import { TabsPage } from '../tabs/tabs';
// import { Storage } from '@ionic/storage';

@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

  list:any;
  profile:any;
  loading:any;
  confirmed:any;
  cust:any;
  user:any;
  pass:any;
  passwordType: string = 'password';
  passwordIcon: string = 'eye-off';
  username:string="username";
  password:string="password";
   
  hideShowPassword() {
    this.passwordType = this.passwordType === 'text' ? 'password' : 'text';
    this.passwordIcon = this.passwordIcon === 'eye-off' ? 'eye' : 'eye-off';
}


  constructor(public navCtrl: NavController, 
    public navParams: NavParams,
    private reditService:RedditService,
    public alertCtrl:AlertController,
    public appCtrl:App,
    public loadingCtrl:LoadingController,
    public nav:Nav,
    public toastCtrl:ToastController,
    // private storage: Storage,
    private sessionService:SessionService,
    private cartService:CartService) {
  }





  login(){

    let loader = this.loadingCtrl.create({
      cssClass:'page-loadings',
      spinner:'dots'
    });
    loader.present().then(() =>{ this.reditService.checklogin(this.user,this.pass).then(data=>{    
      console.log(data);
      this.list=  data;
      this.cust=this.list.customer_account;
       this.confirmed = Object.keys(this.cust).length;
       if(this.confirmed===1){
        // this.user=[];
        // this.pass=[];
        this.sessionService.setUsername(this.user)
        this.sessionService.setPass(this.pass)
         this.sessionService.setLogin();
         this.sessionService.setUser(this.cust);
        //  this.saveToLocal();
          
         
          let toast = this.toastCtrl.create({
            message:'Welcome',
            duration:1200,
            position:'bottom'
          })
        
          this.navCtrl.pop();
       
          toast.present();
          loader.dismiss()
       }
       else{
         this.user=[];
         this.pass=[];
         this.showAlert();
        loader.dismiss()
       }
     
      }),
    
  error=>{
    this.presentErrorToast()
    loader.dismiss();
  };
});

  }

  logOut(){
    this.showMessage();
  }

  showMessage(){
  
    let message=this.alertCtrl.create({
      title:'Log-out your Account',
      message:'Are you sure to log-out from your account?',
      buttons:[{
        text:'NO',
        handler:()=>{
          console.log("Cancelled");
        }
      },
      {
        text:'YES',
        handler:()=>{
        
          this.sessionService.setLogout();
          this.sessionService.clearUser();
          this.nav.pop();
          this.cartService.clearCart();
         
        }
      }
     ]
   });
   message.present();
    }
  
  
    // saveToLocal(){
    //   this.storage.set('username', this.user);
    //   this.storage.set('password', this.pass);
    // }

    presentErrorToast() {
      let toast = this.toastCtrl.create({
        message: "An error occured while signing in to your account!",
        duration: 2000,
        position: 'middle',
      });  
      toast.present();
    
    }
   
  showAlert(){
    let alert=this.alertCtrl.create({
      title:'Login Unsuccessful',
      message:'Incorrect username and password!',
      buttons:['Try Again'],
      cssClass:'alertLogin'
    });
    alert.present();
  }




  // <!-- Pagnag-logout -->
  goLogin(){
    this.navCtrl.push(LoginPage);
  }

  showPop(){
        this.navCtrl.push(HomePage);
  }



     
//   animateElem(){
//     this.animator.setType('fadeInRight').show(this.myElem.nativeElement);
//   }

//  ionViewDidLoad(){
//    this.animateElem();
 


}
 
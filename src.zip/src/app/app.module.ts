import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { DatePipe}from '@angular/common';
import { SuccessPage} from '../pages/success/success'
import { HttpClient, HttpHeaders } from '@angular/common/http'; 
import { HttpClientModule } from '@angular/common/http'; 
import { HTTP } from '@ionic-native/http';
import { AboutPage } from '../pages/about/about';
import { ContactPage } from '../pages/contact/contact';
import { HomePage } from '../pages/home/home';
import { TabsPage } from '../pages/tabs/tabs';
import { CartPage } from '../pages/cart/cart';
import { MenuPage } from '../pages/menu/menu';
import { CheckoutPage } from '../pages/checkout/checkout';

import { RedditService } from '../app/service/redditService';
import { SessionService} from '../app/service/sessionService';
import { CartService} from '../app/service/cartService';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import {LoginPage} from '../pages/login/login';
import { IonicStorageModule } from '@ionic/storage';
import {InforPage} from '../pages/infor/infor';
import {ConnectionPage} from '../pages/connection/connection';
import {OrderlistPage} from '../pages/orderlist/orderlist';
@NgModule({
  declarations: [
    MyApp,
    AboutPage,
    ContactPage,
    HomePage,
    TabsPage,
    CheckoutPage,
    MenuPage,
    CartPage,
    LoginPage,
    SuccessPage,
    ConnectionPage,
    OrderlistPage,
    InforPage
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    IonicModule.forRoot(MyApp),
    IonicStorageModule.forRoot()
 
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    AboutPage,
    ContactPage,
    HomePage,
    TabsPage,
    CheckoutPage,
    MenuPage,
    CartPage,
    LoginPage,
    SuccessPage,
    ConnectionPage,
    OrderlistPage,
    InforPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    CartService,
    DatePipe,
    RedditService,
    HttpClientModule,
    HttpClient,
    SessionService,
   
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}

import { Component } from '@angular/core';
import { NavController,AlertController,LoadingController } from 'ionic-angular';
import { SessionService } from '../../app/service/sessionService';
import { LoginPage } from '../login/login';
import  {RedditService} from '../../app/service/redditService'
import { OrderlistPage } from '../orderlist/orderlist';
@Component({
  selector: 'page-contact',
  templateUrl: 'contact.html'
})
export class ContactPage {
  user:any;
  logState:any=false;
  constructor(public navCtrl: NavController,
              private sessionService:SessionService,
              private redditService:RedditService,
              public loadingCtrl:LoadingController,
              public alertCtrl:AlertController,
             ) {
              this.user=this.sessionService.getUser()
              this.logState = this.sessionService.getLogState();

   
}

gotoLogin(){
  this.navCtrl.push(LoginPage)
}


user_data:any;
user_order:any;
ionViewDidEnter(){
  
  this.logState = this.sessionService.getLogState();
  this.user=this.sessionService.getUser()
  if(this.logState){
    let loader =this.loadingCtrl.create({
      spinner:'dots',
    })
    loader.present().then(()=>{
    this.redditService.getUserOrder(this.user[0].cust_id)
    .then(data=>{
      this.user_data = data;
      this.user_order = this.user_data.orders;
      console.log(this.user_order);
      loader.dismiss();
    })
  })
  }
}


viewOrders(order){
  this.navCtrl.push(OrderlistPage,{
    order_id:order.ord_id
  })
}
}

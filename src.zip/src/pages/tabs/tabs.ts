import { Component,OnInit,Input,OnDestroy } from '@angular/core';
import {CartService} from '../../app/service/cartService';
import { AboutPage } from '../about/about';
import { ContactPage } from '../contact/contact';
import { HomePage } from '../home/home';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/observable/interval';
import 'rxjs/add/operator/switchMap';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { InforPage } from '../infor/infor';
@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage implements OnInit{
myQuerySub:Subscription;
  myIntervalSub:Subscription;
  myQueryObs:Observable<any>;
  totalQuery:any=[];
  tab1Root = HomePage;
  tab2Root = AboutPage;
  tab3Root = ContactPage;
  tab4Root = InforPage;

  constructor(public cartService:CartService) {

  }


  ngOnInit() {
    // this.products$ = Observable
    //   .interval(1000)
    //   .startWith(0).switchMap(() => this.redditService.loadOrderInformation())
    //   this.loadBillout()
     this.myQuerySub=Observable.interval(1000).subscribe(()=>{
      this.cartService.getCart();
      
      this.totalQuery = this.cartService.getCartLength();
     });
  }

}

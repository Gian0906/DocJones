import {Injectable} from '@angular/core';

@Injectable()
export class SessionService{

    loginState:any=false;
    loginUser:any;
    pass:any;
    username:any;
    photo:any;
    constructor()
    {

    }
    setLogin(){
        this.loginState=true;
        console.log(this.loginState);
    }
    setLogout(){
        this.loginState=false;
    }
    setUser(value){
        this.loginUser=value;
    }
    getLogState(){
        return this.loginState;

    }
    getUser(){
        return this.loginUser;
    }
    clearUser(){
        this.loginUser=[];
    }

    setUsername(user){
        this.username = user;
        console.log(this.username)
    }

    setPass(pass){
        this.pass = pass;
        console.log(this.pass);
    }

    getUsername(){
        return this.username;
        }

    getPass(){
        return this.pass;
    }

    updateUserState(value){
        this.loginUser = value;
    }


}
import { Component } from '@angular/core';
import {  NavController, NavParams } from 'ionic-angular';
import {RedditService} from '../../app/service/redditService'



@Component({
  selector: 'page-orderlist',
  templateUrl: 'orderlist.html',
})
export class OrderlistPage {
  order_id:any;
  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              private redditService:RedditService)
              {
              this.order_id = this.navParams.get('order_id')
  }

  order_data:any;
  order_list:any;

  ionViewDidLoad() {
    this.redditService.getOrderList(this.order_id)
    .then(data=>{
      this.order_data = data;
      this.order_list = this.order_data.order_details;
      console.log(this.order_list)
    })
  }

}

import { Component } from '@angular/core';
import { NavController,LoadingController } from 'ionic-angular';
import {LoginPage} from '../login/login'
import { SessionService } from '../../app/service/sessionService';

@Component({
  selector: 'page-about',
  templateUrl: 'about.html'
})
export class AboutPage {
  user:any;
  logState:any=false;
  constructor(public navCtrl: NavController,
              private sessionService:SessionService,
              public loadingCtrl:LoadingController,
              )
              
              
              {

                this.user=this.sessionService.getUser()
                this.logState = this.sessionService.getLogState();
               }


  gotoLogin(){
    this.navCtrl.push(LoginPage)
  }

  ionViewDidEnter(){
  
      this.logState = this.sessionService.getLogState();
      this.user=this.sessionService.getUser()

  }
}

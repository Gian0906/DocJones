import {Injectable} from '@angular/core';
var cart = [];


@Injectable()
export class CartService{
    

    constructor(){
        
        }
        
        addTocart(product,quantity){
            
            var quant = parseInt(quantity)
            
            cart.push({
                id:cart.length,
                product_id:product.menu_id,
                name:product.menu_name,
                price:product.menu_price,
                product_image:product.menu_img,
                quantity:quant,
                desc:product.product_desc,
                product_serving:product.menu_qty
               
               
            });
        
    }

    setCart(cart){
        cart=cart;

    }
    removeItem(id){
        console.log(id)
        cart.splice(id,1)
        for(var i=0; i<cart.length;i++){
            cart[i].id=i;
        }
    }
    clearCart(){
        cart=[];
    }
    getCart()
    {
        return cart;
    }
    getCartLength(){
        return cart.length;
    }
    updateItem(id,quantity){
        cart[id].quantity=quantity;

    }

    updateAddons(id,selected){
        if(selected != []){
        cart[id].selected = selected;

        }
        else{
            cart[id].selected = 'No addons selected'
        }

    }

    updateAddonsPrice(id,addons_amount){
        cart[id].addons_amount = addons_amount;
       
    }

}
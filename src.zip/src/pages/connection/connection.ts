import { Component,Attribute } from '@angular/core';
import { NavController, NavParams,Nav,AlertController,LoadingController } from 'ionic-angular';
import { RedditService } from '../../app/service/redditService';
import {HomePage} from '../home/home';
import { Storage } from '@ionic/storage';


import { TabsPage } from '../tabs/tabs';
/**
 * Generated class for the ConnectionPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */


@Component({
  selector: 'page-connection',
  templateUrl: 'connection.html',
})
export class ConnectionPage {
  connection:any=false;
  page:any;
  IP_Add:any;
  loading:any;
  men:any;
  menu:any;
  flag:any;
  confirmed:any;
  backcolor:any;
  key:string='Ip';
  IP_Flag:any;
  Old_IP:any;
  user:any;
  pass:any;
  list:any;
  cust:any;
  phone:any
  mask:any[]=[ /\d/,/\d/,/\d/,'.', /\d/, /\d/, /\d/, '.',/\d/,'.',/\d/, /\d/, /\d/ ];
  masks: any; 
  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              public nav:Nav,
              public alertCtrl:AlertController,
              public storage:Storage,
              @Attribute('mask') pattern: string,
              public loadingCtrl:LoadingController,
              private reditService:RedditService,) {



                this.masks = {
                  phoneNumber: ['(', /[1-9]/, /\d/, /\d/, ')', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/]
                
              };
  }





  ionViewDidLoad(){
    this.storage.get('Ip').then((val)=>{
      this.IP_Add = val;
      this.Old_IP = val;
      if(this.IP_Add!=undefined){
      this.reditService.checkConnection(this.IP_Add)
      .then(data =>{
        this.men = data;
        this.menu = this.men.customer_account;
          if (this.menu !==undefined){
            if(this.user ==  null && this.pass == null){
            this.nav.setRoot(TabsPage);
            }
           
            }else{
             this.backcolor = false;
              let alert=this.alertCtrl.create({
                enableBackdropDismiss:false,
                title:'Connection Problem',
                message:'Failed to connect to the server. Please check your connection.',
                buttons: [
                  {
                    text: 'OK',
                    handler: ()=> {
                    
                    }
                  }
                ],
                });
                alert.present();
            
            }
      } ,(error)=>{
        console.log("Not Correct");
       });
      }
      });

  }
  
  
  getUserStorage(){
    if(this.user == null && this.pass ==null){
      console.log("1");
      this.reditService.checklogin(this.user,this.pass)
    }
    else{
      console.log("2");
     
    }
  }


  
  checkIpAddress() {    
  
  
        let loader = this.loadingCtrl.create({
          spinner:'dots'
        });
        loader.present().then(() =>{
        this.reditService.checkConnection(this.IP_Add)
        .then(data =>{
          this.men = data;
          this.menu = this.men.customer_account;
          console.log(this.menu);
            if (this.menu!=undefined){
              
              this.backcolor = true;
           
              let alert=this.alertCtrl.create({
              enableBackdropDismiss:false,
              title:'Connected successfull',
              message:'Please reload the app.',
              buttons: [
                {
                  text: 'Reload',
                  handler: ()=> {
                    console.log(this.IP_Add);
                  this.storage.set(this.key, this.IP_Add).then(data=> {
                    window.location.reload();
                  });
                  }
                }
              ],
              });
              alert.present();
              
              loader.dismiss();
            
              console.log("Correct");
              }
              else{
                loader.dismiss();
              }
               
        });
         
          }); 
        // }
      }
  
   
}

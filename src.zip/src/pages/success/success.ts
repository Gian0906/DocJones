import { Component } from '@angular/core';
import { NavController, NavParams,Nav } from 'ionic-angular';
import { TabsPage } from '../tabs/tabs';


@Component({
  selector: 'page-success',
  templateUrl: 'success.html',
})
export class SuccessPage {

  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              public nav:Nav) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SuccessPage');
  }
  gotoHome(){
    this.nav.setRoot(TabsPage)
  }
}

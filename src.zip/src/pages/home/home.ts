import { Component } from '@angular/core';
import { NavController,Nav } from 'ionic-angular';
import {RedditService} from '../../app/service/redditService';
import {MenuPage} from '../menu/menu';
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  url:any;
  menu_list:any;
  menu_data:any;
  cartPanel:any=false;
  constructor(public navCtrl: NavController,
              public nav:Nav,
              public redditService:RedditService) {

              this.url = this.redditService.getUrl();
              console.log(this.url); 

  }

data_list:any;
data_test:any;
ionViewDidEnter(){
  this.redditService.getTown()
  .then(data=>{
    this.data_list = data;
    this.data_test = this.data_list.category;
    console.log(this.data_test);
  })
}



showProducts(items){
  this.navCtrl.push(MenuPage,{
    items:items
  })

}



closePanel(){
  this.cartPanel = false;
}

}

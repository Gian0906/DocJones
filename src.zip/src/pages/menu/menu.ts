import { Component } from '@angular/core';
import {  NavController, NavParams, AlertController,ToastController } from 'ionic-angular';
import {RedditService} from '../../app/service/redditService';
import {CartService} from '../../app/service/cartService';
import {CartPage} from '../cart/cart';

@Component({
  selector: 'page-menu',
  templateUrl: 'menu.html',
})
export class MenuPage {
   items:any;
   menu_list:any;
   menu_data:any;
  cartQty:any;
  totalQuery:any;
  cart:any;
  cartPanel:any=false;
  cartItem:any;
  url:any;
  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              public toastCtrl:ToastController,
              public alertCtrl:AlertController,
              public redditService:RedditService,
              public cartService:CartService) { 
              this.items = this.navParams.get('items');
              console.log(this.items);

              this.cart=this.cartService.getCart();
              console.log(this.cart)
                 
              this.url = this.redditService.getUrl();

              this.totalQuery = this.cartService.getCartLength();
  
  }



  ionViewDidLoad() {
    this.redditService.getProductbyCategory(this.items)
    .then(data=>{
      this.menu_data = data;
      this.menu_list = this.menu_data.menu;
      console.log(this.menu_list);  
    })
    
  }


  
  add(){
    this.cartQty ++;
  }

  minus(){
    this.cartQty --;
  }

  showPanel(item){
    this.cartPanel = true;
    console.log(item)
    this.cartItem = item;
    this.cartQty =1;
  }

  addcart(item){
    if(this.cartQty > item.menu_qty){
      let alert = this.alertCtrl.create({
        title:'Check Quantity',
        message:'Quantity must be less than or equal to the available order.',
        buttons:['Ok']
      })
      alert.present();
    }
    else if(this.cartQty < 1){
      let alert = this.alertCtrl.create({
        title:'Check Quantity',
        message:'Invalid Quantity',
        buttons:['Ok']
      })
      alert.present();
    }
    else if(this.cartQty % 1){
      let alert = this.alertCtrl.create({
        title:'Check Quantity',
        message:'Invalid Quantity',
        buttons:['Ok']
      })
      alert.present();
    }
    else{
    var check;
    var cart;
    for(var i=0; i<this.cart.length; i++){
      if(this.cart[i].product_id==item.menu_id){
        check=1;
      
        cart=this.cart[i].id;
     
      }
    }
    if(check==1){
      this.cartPanel = false;
      let confirm=this.alertCtrl.create({
        title:'Check Cart',
        message:'Menu already on the Cart!',
        cssClass:'listAlert.scss',
        buttons:[
          {
            text:'Ok',
            handler:()=>{
          
            }
          },
        ]
        

      });
      confirm.present();
    }
    else{
      this.presentToast(item);
      this.cartService.addTocart(item,this.cartQty);
      this.totalQuery=this.cartService.getCartLength();
      this.cart = this.cartService.getCart();
      console.log(this.cart);
      this.cartPanel = false;
    }
  }
  }

  presentToast(item) {
    let toast = this.toastCtrl.create({
      message: item.menu_name+' added to the cart',
      duration: 1000,
      position: 'top'
    });
    toast.present();
  }


  closePanel(){
    this.cartPanel = false;
  }


  ViewCart(){
    if(this.totalQuery == 0){
      let alert = this.alertCtrl.create({
        title:'Cart is Empty',
        buttons:['Ok']
      })
      alert.present();
    }
    else{
    this.navCtrl.push(CartPage);
    }
  }
}
